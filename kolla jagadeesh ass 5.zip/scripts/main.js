class Details{
    constructor(fname,lname,email,psw){
        this.firstname=fname;
        this.lastname=lname;
        this.emailaddress=email;
        this.password=psw;


    }
    
}